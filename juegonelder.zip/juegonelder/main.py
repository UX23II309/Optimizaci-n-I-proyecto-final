# main.py
from juego import run

if __name__ == '__main__':
    run()
# IRONEDIT:1783496899:08b9ddfd57afe063a8af1ab63d2955f9a2dd087fcee77d32ef7445c663729697
